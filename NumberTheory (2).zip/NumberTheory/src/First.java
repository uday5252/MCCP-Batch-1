
public class First {
	public static void main(String[] args) {
		
		int N = 100;
//		1 and 100
		
		for(int i = 2; i < N; i++)
		{
			if(N % i == 0)
			{
				System.out.println("Not a prime");
			}
		}

	}
}
