
public class Third {

	public static void main(String[] args) {
		
		int N = 100;
		
		
		
		boolean primeNoTracker[] = 
				new boolean[N + 1];
//		2,3,4,5,6,7,8,9,10
//		F,F,F,F,T,F,T,F,T,T,T
//		true ==> not prime
//		false ==> prime
		
		for(int i = 2; i <= Math.sqrt(N); i++)
		{
//			2 times(i = 2 and i = 3)
//			i = 2
			for(int j = i * 2; j <= N; j = j+ i)
			{
				primeNoTracker[j] = true; 
			}
		}

		for(int i = 2; i <= N; i++)
		{
			if(primeNoTracker[i] == false)
			{
				System.out.println(i);
			}
			
		}
}
	
}
