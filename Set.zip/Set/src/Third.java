
public class Third {

	public static void main(String[] args) {
		
		int N = 17;
		
		
		double num = Math.floor(Math.sqrt(N));
		
		for(int i = 2; i <= num; i++)
		{
			if( N % i != 0)
			{
				System.out.println("Prime No");
			}
			else
			{
				System.out.println("Not a Prime No!");
			}
		}

	}

}
