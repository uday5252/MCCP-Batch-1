import java.util.Collections;
import java.util.TreeSet;

public class First {
	public static void main(String[] args) {
	
		
//		HashSet hs = new HashSet();
//		hs.add(10);
//		hs.add(20);
//		hs.add(5);
//		hs.add(40);
//		hs.add(30);
//		hs.add(20);
//		
//		System.out.println(hs);
		
//		LinkedHashSet hs = new LinkedHashSet();
//		hs.add(10);
//		hs.add(20);
//		hs.add(5);
//		hs.add(40);
//		hs.add(30);
//		hs.add(20);
//		
//		System.out.println(hs);

//		TreeSet hs = new TreeSet(Collections.reverseOrder());
//		
//		hs.add(10);
//		hs.add(20);
//		hs.add(5);
//		hs.add(40);
//		hs.add(30);
//		hs.add(20);
//			
//		System.out.println(hs);
		

	}

}
