
public class Second {

	public static void main(String[] args) {
		
		int N = 24; //4.9
		
		for(int i = 2; i < N; i++)
		{
			if(N % i == 0)
			{
				System.out.println("Not a prime no!");
			}
			else
			{
				System.out.println("Prime No!");
			}
		}

	}

}
