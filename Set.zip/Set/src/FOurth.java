
public class FOurth {

	public static void main(String[] args) {
		
//		48 and 36 ==> 12
		
		int a = 48;
		int b = 36;
		
		while(a != b)
		{
			if(a > b)
			{
				a = a - b;
			}
			else
			{
				b = b - a;
			}
		}
		
		System.out.println(b);
	}

}
