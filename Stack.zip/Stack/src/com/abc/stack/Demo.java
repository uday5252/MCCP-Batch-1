package com.abc.stack;

import java.util.Collections;
import java.util.PriorityQueue;

public class Demo {

	public static void main(String[] args) {
		
		
//		PriorityQueue<Integer> minHeap = new PriorityQueue<Integer>();
//		minHeap.add(5);
//		minHeap.add(3);
//		minHeap.add(50);
//		minHeap.add(10);
//		minHeap.add(8);
//		minHeap.add(1);
//		
//		System.out.println(minHeap);
		

//        PriorityQueue<Integer> maxHeap =
//                new PriorityQueue<Integer>(Collections.reverseOrder());
//
//        maxHeap.add(5);
//        maxHeap.add(3);
//        maxHeap.add(50);
//        maxHeap.add(10);
//        maxHeap.add(8);
//        maxHeap.add(1);
//
//        System.out.println(maxHeap);
		
		 // Max Heap → smaller half
        PriorityQueue<Integer> maxHeap =
                new PriorityQueue<>(Collections.reverseOrder());

        // Min Heap → larger half
        PriorityQueue<Integer> minHeap =
                new PriorityQueue<>();

        int[] nums = {5, 3, 8, 10};

        for (int num : nums) {

            maxHeap.add(num);

            minHeap.add(maxHeap.poll());

            if (minHeap.size() > maxHeap.size()) {
                maxHeap.add(minHeap.poll());
            }
        }
        
        // Even number
        if (maxHeap.size() == minHeap.size()) {

            double median =
                    (maxHeap.peek() + minHeap.peek()) / 2.0;

            System.out.println("Median = " + median);
        }

	}

}
