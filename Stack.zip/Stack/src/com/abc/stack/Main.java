package com.abc.stack;

import java.util.PriorityQueue;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {

        // Max Heap → smaller half
        PriorityQueue<Integer> maxHeap =
                new PriorityQueue<>(Collections.reverseOrder());

        // Min Heap → larger half
        PriorityQueue<Integer> minHeap =
                new PriorityQueue<>();
        
        

        int[] nums = {10, 3, 4, 12};
        
//        3,4 ==> max
//        10,12 ==> min
        
//        max = 3, 4
//        min = 10, 12
        
        
        for (int num : nums) {

        	
        	
        	
        
            if (maxHeap.isEmpty() || num <= maxHeap.peek()) {
                maxHeap.add(num);
            } else {
                minHeap.add(num);
            }

            if (maxHeap.size() > minHeap.size()) {
                minHeap.add(maxHeap.poll());
            }
            else if (minHeap.size() > maxHeap.size()) {
                maxHeap.add(minHeap.poll());
            }
        }

        // For even number of elements,
        // both heaps have the same size

        double median =
                (maxHeap.peek() + minHeap.peek()) / 2.0;

        System.out.println("Median: " + median);
    }
}