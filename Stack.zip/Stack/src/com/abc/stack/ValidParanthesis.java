package com.abc.stack;

import java.util.Stack;

public class ValidParanthesis {

	public static void main(String[] args) {
		
		String s = "[{(})]";
		
		Stack<Character> st = new Stack<Character>();

		for(int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i) == '(' 
					|| s.charAt(i) == '[' 
					|| s.charAt(i) == '{')
			{
				st.add(s.charAt(i));
			}
			else
			{
				Character lastEle = st.pop(); //(
				if(
						(s.charAt(i) == ')' && lastEle != '(' )
						||
						(s.charAt(i) == '}' && lastEle != '{' )
						||
						(s.charAt(i) == ']' && lastEle != '[' ))
				{
					System.out.println("FALSE");
				}
				
			}
		}
		

		
		
	}

}
