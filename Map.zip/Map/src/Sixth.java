import java.util.HashSet;

public class Sixth {

	public static void main(String[] args) {
		int n = 5;
		int arr[] = { 3, 4, 1, 5 };
		
		HashSet<Integer> set = new HashSet<Integer>();
		
		for(int i : arr)
		{
			set.add(i);
		}
		
		for(int i = 1; i <= n; i++)
		{
			if(!set.contains(i))
			{
				System.out.println(i);
			}
		}
		

	}

}
