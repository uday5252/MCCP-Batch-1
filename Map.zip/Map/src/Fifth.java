
public class Fifth {

	public static void main(String[] args) {
	
		int n = 5;
		int arr[] = { 3, 4, 1, 5 };
		int xorActual = 0;
		
		for(int i : arr)
		{
			xorActual = xorActual ^ i;
		}
		
		int xorExpected = 0;
		for(int i = 1; i <= n; i++)
		{
			xorExpected = xorExpected ^ i;
		}
		
		System.out.println(xorActual ^ xorExpected);
		
		
		

	}

}
