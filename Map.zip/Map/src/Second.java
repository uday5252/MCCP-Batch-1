import java.util.HashMap;

public class Second {

	public static void main(String[] args) {
		
		 HashMap<Integer, String> map = new HashMap<>();

		  	map.put(50, "A");
	        map.put(10, "B");
	        map.put(40, "C");
	        map.put(20, "D");

	        System.out.println(map);

	}

}
