import java.util.Scanner;

public class First {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
		long number = sc.nextLong();
		
		long position = number % 60;
		
		long a = 0;
		long b = 1;
		
		for(int i = 0; i < position; i++)
		{
			long c = (a + b) % 10;
			a = b;
			b = c;
		}
		System.out.println(a);

	}

}
