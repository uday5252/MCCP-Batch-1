import java.util.ArrayList;
import java.util.Collections;

public class Seventh {

	public static void main(String[] args) {
		
		int arr[] = { 16, 17, 4, 3, 5, 2 };
		
		ArrayList<Integer> al = new ArrayList();
		//2, 5, 17
		
		int maxIndex = arr.length - 1;
		al.add(arr[maxIndex]);
		
		for(int i = arr.length - 2; i >= 0; i--) {
			if(arr[i] > arr[maxIndex])
			{
				al.add(arr[i]);
				maxIndex = i;
			}
		}
		
		Collections.reverse(al);
		System.out.println(al);
	}

}
