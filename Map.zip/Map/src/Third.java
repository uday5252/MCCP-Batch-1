import java.util.Collections;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Third {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);	
//		System.out.println("Enter the number:");
//		int num = scan.nextInt();
//		
//		int result = num >> 1;
//		
//		System.out.println(result);
		
		
//		Scanner scan = new Scanner(System.in);	
//		System.out.println("Enter the number:");
//		int num = scan.nextInt();
//		
//		int result = num << 1;
//		
//		System.out.println(result);
		
		
		
//		Scanner scan = new Scanner(System.in);	
//		System.out.println("Enter the number:");
//		int num = scan.nextInt();//13
//		
//		int count = 0;
//		int result = num & 1;
//		if(result == 1)
//		{
//			count++;
//		}
//		System.out.println(count);  
		
		
//		HashMap<Integer, String> map = new HashMap<>();
//		
//		map.put(50, "A");
//        map.put(10, "B");
//        map.put(40, "C");
//        map.put(20, "D");
//		
//		System.out.println(map);
		
		
		
		
//		LinkedHashMap<Integer, String> map = 
//				new LinkedHashMap<>();
//		
//		map.put(50, "A");
//        map.put(10, "B");
//        map.put(40, "C");
//        map.put(20, "D");
//		
//		System.out.println(map);
		
		
//		Scanner scan = new Scanner(System.in);
//		
//		LinkedHashMap<String, String> map = 
//				new LinkedHashMap();
//		
//		while(true)
//		{
//				System.out.println("Enter the department name:");
//				String dName = scan.next();
//				
//				System.out.println("Enter the department HOD:");
//				String dHod = scan.next();
//				
//				map.put(dName, dHod);
//				
//				System.out.println("Do you want to conitnue? type"
//						+ " y-yes OR n-no");
//				
//				String optionChoosen = scan.next().toLowerCase();
//				if(optionChoosen.equals("n"))
//				{
//					break;
//				}
//				
//				
//		}
//		
//		System.out.println(map);
		
//		Scanner scan = new Scanner(System.in);
//		
//		TreeMap<String, String> map = 
//				new TreeMap(Collections.reverseOrder());
//		
//		while(true)
//		{
//				System.out.println("Enter the department name:");
//				String dName = scan.next();
//				
//				System.out.println("Enter the department HOD:");
//				String dHod = scan.next();
//				
//				map.put(dName, dHod);
//				
//				System.out.println("Do you want to conitnue? type"
//						+ " y-yes OR n-no");
//				
//				String optionChoosen = scan.next().toLowerCase();
//				if(optionChoosen.equals("n"))
//				{
//					break;
//				}
//				
//				
//		}
//		
//		System.out.println(map.keySet());
		
		
		
//		TreeMap<String, String> map = new TreeMap<>();
//
//        // 2. Add Indian department names as keys and HOD names as values
//        map.put("Physics", "Dr. H. J. Bhabha");
//        map.put("Mathematics", "Dr. C. S. Seshadri");
//        map.put("Computer Science", "Dr. A. K. Choudhury");
//        map.put("Chemistry", "Dr. C. N. R. Rao");
//        
//        for( Map.Entry<String, String> i : map.entrySet())
//        {
//        	System.out.println(
//        			"Department Name: "+i.getKey()
//        			+
//        			" Department HOD: "+i.getValue()
//        			);
//        }
		
//		TreeMap<String, String> map = new TreeMap<>(Collections.reverseOrder());
//
//        // 2. Add Indian department names as keys and HOD names as values
//        map.put("Physics", "Dr. H. J. Bhabha");
//        map.put("Mathematics", "Dr. C. S. Seshadri");
//        map.put("Computer Science", "Dr. A. K. Choudhury");
//        map.put("Chemistry", "Dr. C. N. R. Rao");
//        
//        for( Map.Entry<String, String> i : map.entrySet())
//        {
//        	System.out.println(
//        			"Department Name: "+i.getKey()
//        			+
//        			" Department HOD: "+i.getValue()
//        			);
//        }
		
//		TreeMap<String, String> map = new TreeMap<>(Collections.reverseOrder());
//
//        // 2. Add Indian department names as keys and HOD names as values
//        map.put("Physics", "Dr. H. J. Bhabha");
//        map.put("Mathematics", "Dr. C. S. Seshadri");
//        map.put("Computer Science", "Dr. A. K. Choudhury");
//        map.put("Chemistry", "Dr. C. N. R. Rao");
//        
//        String largestSubjectName = map.firstKey();
//		
//        System.out.println(map.get(largestSubjectName));
		
		
//		TreeMap<String, String> map = new TreeMap<>();
//
//        // 2. Add Indian department names as keys and HOD names as values
//        map.put("Physics", "Dr. H. J. Bhabha");
//        map.put("Mathematics", "Dr. C. S. Seshadri");
//        map.put("Computer Science", "Dr. A. K. Choudhury");
//        map.put("Chemistry", "Dr. C. N. R. Rao");
//        
//        String largestSubjectName = map.firstKey();
//		
//        System.out.println(map.get(largestSubjectName));
//		
		
		TreeMap<String, String> map = new TreeMap<>();

        // 2. Add Indian department names as keys and HOD names as values
        map.put("Physics", "Dr. H. J. Bhabha");
        map.put("Mathematics", "Dr. C. S. Seshadri");
        map.put("Computer Science", "Dr. A. K. Choudhury");
        map.put("Chemistry", "Dr. C. N. R. Rao");
      
      
        for( Map.Entry<String, String> i : map.entrySet())
        {
        	if(i.getKey().startsWith("C"))
        	{
        		System.out.println(i.getKey());
        	}
        }
		
		
		
		
		
		
		
		
		
		
		
	}
}
