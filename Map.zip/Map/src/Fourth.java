




public class Fourth {

	public static void main(String[] args) {
		
		int n = 7;
		int arr[] = {1, 4, 2, 3, 6, 7};
		
		long expectedSum = n * (n + 1) / 2;
		
		int actualSum = 0;
		
		for(int i : arr)
		{
			actualSum = actualSum + i;
		}
		
		System.out.println(expectedSum - actualSum);
		

	}

}
